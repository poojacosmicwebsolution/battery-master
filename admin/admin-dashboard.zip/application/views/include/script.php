
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		

		<!-- Bootstrap js-->
		<script src="<?php echo ASSETS; ?>assets/plugins/bootstrap/js/popper.min.js"></script>
		<script src="<?php echo ASSETS; ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		

		<!-- Peity js-->
		<script src="<?php echo ASSETS; ?>assets/plugins/peity/jquery.peity.min.js"></script>

		<!-- Select2 js-->
		<script src="<?php echo ASSETS; ?>assets/plugins/select2/js/select2.min.js"></script>

		<!-- Perfect-scrollbar js -->
		<script src="<?php echo ASSETS; ?>assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Sidemenu js -->
		<script src="<?php echo ASSETS; ?>assets/plugins/sidemenu/sidemenu.js"></script>

		<!-- Sidebar js -->
		<script src="<?php echo ASSETS; ?>assets/plugins/sidebar/sidebar.js"></script>

		<!-- Internal Apexchart js-->
		

		<!-- Internal Polyfills js-->
		<script src="<?php echo ASSETS; ?>assets/plugins/polyfill/polyfill.min.js"></script>
		<script src="<?php echo ASSETS; ?>assets/plugins/polyfill/classList.min.js"></script>
		<script src="<?php echo ASSETS; ?>assets/plugins/polyfill/polyfill_mdn.js"></script>


		<!-- Sticky js -->
		<script src="<?php echo ASSETS; ?>assets/js/sticky.js"></script>

		

		<!-- Custom js -->
		<script src="<?php echo ASSETS; ?>assets/js/custom.js"></script>
		<script src="<?php echo ASSETS; ?>assets/js/jquery.validate.js"></script>
		<script src="<?php echo ASSETS; ?>assets/js/additional-methods.js"></script>