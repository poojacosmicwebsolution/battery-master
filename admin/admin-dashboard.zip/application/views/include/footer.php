<!-- Main Footer-->
			<div class="main-footer text-center">
				<div class="container">
					<div class="row row-sm">
						<div class="col-md-12">
							<span>Copyright © <?php echo date("Y"); ?> <a href="#">Cosmic</a>. Designed by <a href="https://www.spruko.com/">Cosmic Web Solutions</a> All rights reserved.</span>
						</div>
					</div>
				</div>
			</div>
			<!--End Footer-->