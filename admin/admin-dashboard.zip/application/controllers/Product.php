<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	function __construct(){
		parent::__construct();
		if(empty($this->session->userdata('aid'))){
			redirect(base_url("Auth"));
		}
		$this->load->model("Product_model",'pm');
		$this->load->model("Media_model",'mm');
		$this->load->model("Category_model",'cm');
	}

	public function index()
	{
		// print_r($this->session->userdata());die;
		$data = array();
		$data['products'] = $this->pm->getAllProducts();	
		$this->load->view('products/products-list',$data);
	}
	public function add()
	{
		$data = array();
		$data['media'] = $this->mm->getAllMedia();
		$data['taxes'] = $this->common_model->getAllTaxes();
		$data['categories'] = $this->cm->getAllCategories();
		$this->load->view('products/products-add',$data);
	}
	public function add_product(){
		// echo "<pre>";
		// print_r($_POST);die;
		if(!empty($this->input->post('product_name'))){
		$this->load->helper('text');
		$this->load->helper('url');
		$slug = url_title(convert_accented_characters($this->input->post('product_name')), 'dash', true);
        // echo "<pre>";
        // print_r($this->input->post());die;
		if(!empty($this->input->post('id'))){
		    if(($this->input->post('sizes')==!null)){
		        $result = $this->db->where("product_id",$this->input->post('id'))->delete("tbl_product_sizes");
		        $sizes = $this->input->post('sizes');
		        for($i=0;$i<count($sizes);$i++){ 
		            $info = array(
		                "product_id"=>$this->input->post('id'),
		                "size_id"=>$sizes[$i]
		                );
		            $query = $this->db->insert("tbl_product_sizes",$info);
		        }
		    }
		    if(($this->input->post('new_arrival')==!null)){
				$new_arrival=1;
			}else{ 
				$new_arrival=0;
			}

			if(($this->input->post('best_seller')==!null)){
				$best_seller=1;
			}else{ 
				$best_seller=0;
			}

			if(($this->input->post('on_sale')==!null)){
				$on_sale=1;
			}else{ 
				$on_sale=0;
			}

			if(($this->input->post('free_delivery')==!null)){
				$free_delivery=1;
			}else{ 
				$free_delivery=0;
			}

	    	$ins = array(
	    		"category_id"=>$this->input->post('category_id'),
	    		"tags"=>$this->input->post('tags'),
	    		"tax_id"=>$this->input->post('tax_id'),
	    		"type"=>$this->input->post('type'),
	    		"name"=>$this->input->post('product_name'),
	    		"short_description"=>$this->input->post('short_description'),
	    		"new_arrival"=>$new_arrival,
				"free_delivery"=>$free_delivery,
	    		"best_seller"=>$best_seller,
	    		"on_sale"=>$on_sale,
	    		"description"=>$this->input->post('product_description'),
	    		"indicator"=>$this->input->post('indicator'),
	    		"image"=>$this->input->post('path'),
	    		"other_images"=>json_encode($this->input->post('extra_images')),
	    		"warranty_guarantte_text"=>$this->input->post('warantry_guarantte_text'),
	    		"made_in"=>$this->input->post('made_in'),
	    		"slug"=>$slug,
	    		"modified"=>date("Y-m-d H:i:s"),
	    	);
	    	$this->db->where("id",$this->input->post("id"));
	    	$this->db->update("tbl_products",$ins);
	    	$this->session->set_flashdata("success","Product Updated Successfully");
		}else{
		     
		    if(($this->input->post('new_arrival')==!null)){
				$new_arrival=1;
			}else{ 
				$new_arrival=0;
			}

			if(($this->input->post('best_seller')==!null)){
				$best_seller=1;
			}else{ 
				$best_seller=0;
			}

			if(($this->input->post('on_sale')==!null)){
				$on_sale=1;
			}else{ 
				$on_sale=0;
			}

			if(($this->input->post('free_delivery')==!null)){
				$free_delivery=1;
			}else{ 
				$free_delivery=0;
			}
				
			$ins = array(
	    		"category_id"=>$this->input->post('category_id'),
	    		"tags"=>$this->input->post('tags'),
	    		"tax_id"=>$this->input->post('tax_id'),
	    		"type"=>$this->input->post('type'),
	    		"name"=>$this->input->post('product_name'),
	    		"short_description"=>$this->input->post('short_description'),
	    		"new_arrival"=>$new_arrival,
	    		"best_seller"=>$best_seller,
			    "free_delivery"=>$free_delivery,
	    		"on_sale"=>$on_sale,
	    		"description"=>$this->input->post('product_description'),
	    		"indicator"=>$this->input->post('indicator'),
	    		"image"=>$this->input->post('path'),
	    		"other_images"=>json_encode($this->input->post('extra_images')),
	    		"warranty_guarantte_text"=>$this->input->post('warantry_guarantte_text'),
	    		"made_in"=>$this->input->post('made_in'),
	    		"slug"=>$slug,
	    		"created"=>date("Y-m-d H:i:s"),
	    	);
	    	$insert_id=$this->db->insert("tbl_products",$ins);
	    	$insert_id = $this->db->insert_id();
	    	if(($this->input->post('sizes')==!null)){
		      //  $result = $this->db->where("product_id",$insert_id)->delete("tbl_product_sizes");
		        $sizes = $this->input->post('sizes');
		        for($i=0;$i<count($sizes);$i++){
		            $info = array(
		                "product_id"=>$insert_id,
		                "size_id"=>$sizes[$i]
		             );
		            $query = $this->db->insert("tbl_product_sizes",$info);
		        }
		    }
	    	$this->session->set_flashdata("success","Product Added Successfully");
		}
		}else{
			$this->session->set_flashdata("error","Product Name cannot be empty");
		}
    	redirect(base_url("Product"));
                       
               
	}
	public function edit($id)
	{
		$data = array();
		$data['product'] = $this->pm->getSingleProduct($id);
		$data['media'] = $this->mm->getAllMedia();
		$data['taxes'] = $this->common_model->getAllTaxes();
		$data['categories'] = $this->cm->getAllCategories(); 
		$sizes=$this->db->where("product_id",$id)->get('tbl_product_sizes')->result_array();
		$temp=array();
		foreach($sizes as $s){
		    $temp[] = $s['size_id'];
		}
		$data['sizes'] = $temp;
		$this->load->view('products/products-add',$data);
	}
	public function delete($id){
		$this->db->where("id",$id);
		$this->db->delete("tbl_products");
		$this->session->set_flashdata("success","Product Deleted Successfully");
		redirect(base_url("Product"));
	}
	public function variants($product_id){
		$data = array();
		$data['product'] = $this->pm->getSingleProduct($product_id);
		$data['variants'] = $this->pm->getProductVariants($product_id);
		$data['attributes'] = $this->pm->getProductAttributes($product_id);
		$data['media'] = $this->mm->getAllMedia();
		$data['all_attributes'] = $this->db->get("tbl_attributes")->result_array();
		$this->load->view('products/products-variant-attributes',$data);
	}
	public function add_attribute(){
		$product_id = $this->input->post("product_id");
		$attribute_id = $this->input->post("attribute_id");

		if(!empty($this->input->post("product_attribute_id"))){
			$product_attribute_id = $this->input->post("product_attribute_id");
			$ins = array(
				'attribute_id'=>$this->input->post("attribute_id"),
				'value'=>$this->input->post("attribute_value"),
				'code'=>$this->input->post("attribute_code"),
				'path'=>json_encode($this->input->post("path")),
				'product_id'=>$this->input->post("product_id"),
			);

			$this->db->where("id",$product_attribute_id);
			$res = $this->db->update("tbl_product_attributes",$ins);
			if($res){
				$this->session->set_flashdata("success","Attribute Updated for product.");
			}else{
				$this->session->set_flashdata("error","Error while updating attribute");

			}

		}else{


			$ins = array(
				'attribute_id'=>$this->input->post("attribute_id"),
				'value'=>$this->input->post("attribute_value"),
				'product_id'=>$this->input->post("product_id"),
				'code'=>$this->input->post("attribute_code"),
				'path'=>json_encode($this->input->post("path")),
			);
			$res = $this->db->insert("tbl_product_attributes",$ins);
				if($res){
				$this->session->set_flashdata("success","Attribute Added to product.");
			}else{
				$this->session->set_flashdata("error","Error while adding attribute to product");

			}

		}
		
		redirect(base_url()."Product/variants/".$product_id);
	}
	function delete_attribute($id,$product_id){
		$this->db->where("id",$id);
		$this->db->delete("tbl_product_attributes");
		$this->session->set_flashdata("success","Product Attribute Deleted Successfully");
		redirect(base_url("Product/variants/".$product_id));
	}
	function add_Variant(){
		$product_id = $this->input->post("product_id");

		if(!empty($this->input->post("product_variant_id"))){
			$product_variant_id = $this->input->post("product_variant_id");
			$ins = array(
				'variant_text'=>$this->input->post("variant_text"),
				'price'=>$this->input->post("price"),
				'special_price'=>$this->input->post("special_price"),
				'sku'=>$this->input->post("sku"),
				'stock'=>$this->input->post("stock"),
				'product_id'=>$this->input->post("product_id"),
			);
			$this->db->where("id",$product_variant_id);
			$res = $this->db->update("tbl_product_variants",$ins);
			if($res){
				$this->session->set_flashdata("success","Variant Updated for product.");
			}else{
				$this->session->set_flashdata("error","Error while updating variant");

			}

		}else{

			

			$ins = array(
				'variant_text'=>$this->input->post("variant_text"),
				'price'=>$this->input->post("price"),
				'special_price'=>$this->input->post("special_price"),
				'sku'=>$this->input->post("sku"),
				'stock'=>$this->input->post("stock"),
				'product_id'=>$this->input->post("product_id"),
			);
			$res = $this->db->insert("tbl_product_variants",$ins);
				if($res){
				$this->session->set_flashdata("success","Variant Added to product.");
			}else{
				$this->session->set_flashdata("error","Error while adding Variant to product");

			}

		}
		
		redirect(base_url()."Product/variants/".$product_id);
	}
	function delete_variant($id,$product_id){
		$this->db->where("id",$id);
		$this->db->delete("tbl_product_variants");
		$this->session->set_flashdata("success","Product Variant Deleted Successfully");
		redirect(base_url("Product/variants/".$product_id));
	}

}
