<?php 
$config = array(
    'protocol' => 'mail',
    'smtp_host' => 'mail.googlehai.com', 
    'smtp_port' => 465,
    'smtp_user' => 'mail@googlehai.com',
    'user_mail' => 'mail@googlehai.com',
    'smtp_pass' => ')MxjOe,}Vdh=',
    'smtp_crypto' => 'ssl',
    'mailtype' => 'html',
    'smtp_timeout' => '4', 
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
);
?>